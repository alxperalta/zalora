function splitMessage(){

	var message = document.getElementById('message').value;
	message = message.trim();
	//get message length
	var messageLength = message.length;
	var splitStrings = [];
	var indicatorLength = 0;

	if(messageLength <= 50){
		splitStrings.push(message);
	} else {
		// get length of split strings
		indicatorLength = getPartIndicator(messageLength);

		var start = 0;
		var end = 50 - (3+indicatorLength.toString().length);
		var  i = 1;
		while(i <= indicatorLength){

			var subString = message.substr(start, end);
			if(subString === ""){ indicatorLength = --i; break; }
			var pos = start + end;
			var nextstring = message.substr(pos, 1);

			if(nextstring !== " " && nextstring.length > 0){
				var split = subString.split("");
				var length = split.length;
				while(split[length] !== " "){
					length--;
					continue;
				}

				subString = message.substr(start, length);
				start += length;
			} else {
				start += end;
			}
			var cutMessage = i+"/xxx "+ subString;
			splitStrings.push(cutMessage);

			end = 50 - (i.toString().length+2+indicatorLength.toString().length);
			i++;
		}

	}

	// display messsages
	displayMessages(splitStrings, indicatorLength);
}

function getPartIndicator(messageLength){

	var divideStringLength = messageLength / 50;
	divideStringLength = Math.ceil(divideStringLength);

	var count = divideStringLength.toString().length;
	var arr = {1 : 9, 2 : 90, 3 : 900};

	var total = 0;
	var i = 1;
	// + 2 fixed values slash "/" and a space " "
	while(i <= count){
		if(i !== count){
			total += (arr[i] * (i + 2 + count));
		} else {
			total += ((arr[i] - divideStringLength)  * (i + 2 + count));
		}

		i++;
	}

	messageLength += total;
	divideStringLength = Math.ceil(messageLength / 50) + 1;

	return divideStringLength;

}

function displayMessages(splitStrings, indicatorLength){
	var splitTemplates = "";
	splitStrings.forEach(function(row) {
		row = row.replace("xxx", indicatorLength);
		var template = "<div class='alert alert-primary' role='alert'>";
		template += row;
		template += "</div>";
		splitTemplates += template;
	});

	document.getElementById('splitMessages').innerHTML = splitTemplates;
}

function clearMessage(){
	document.getElementById('message').value = "";
	document.getElementById('splitMessages').innerHTML = "";
}

document.getElementById('postMessage').addEventListener("click", splitMessage);
document.getElementById('clearMessage').addEventListener("click", clearMessage);
